var searchData=
[
  ['value_20pool_20concept',['Value Pool Concept',['../group__CPP__CONCEPTS__VALUE__POOL.html',1,'']]],
  ['value_5ftype',['value_type',['../classembb_1_1base_1_1Allocator.html#a9d1c6cd1ddafcb8dc424e3ed7b7a8a3e',1,'embb::base::Allocator::value_type()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#a5588fe46533795ba8052bae34781b9f3',1,'embb::base::AllocatorCacheAligned::value_type()']]]
];
