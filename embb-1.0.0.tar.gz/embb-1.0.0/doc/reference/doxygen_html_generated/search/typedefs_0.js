var searchData=
[
  ['const_5fpointer',['const_pointer',['../classembb_1_1base_1_1Allocator.html#a1d216e31cdd0d092c97f49153d635ac9',1,'embb::base::Allocator::const_pointer()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#a273cee75fe41563fd1ca8908088370dc',1,'embb::base::AllocatorCacheAligned::const_pointer()']]],
  ['const_5freference',['const_reference',['../classembb_1_1base_1_1Allocator.html#a88224a0e611cd6ad0c63d0d5d998a3cd',1,'embb::base::Allocator::const_reference()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#ac20cbb76978326e03c8673b12b6d12e4',1,'embb::base::AllocatorCacheAligned::const_reference()']]]
];
