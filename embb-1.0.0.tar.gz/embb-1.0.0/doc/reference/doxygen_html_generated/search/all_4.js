var searchData=
[
  ['duration_20and_20time',['Duration and Time',['../group__C__BASE__DURATIONTIME.html',1,'']]],
  ['duration_20and_20time',['Duration and Time',['../group__CPP__BASE__TIMEDURATION.html',1,'']]],
  ['dataflow',['Dataflow',['../group__CPP__DATAFLOW.html',1,'']]],
  ['deallocate',['deallocate',['../classembb_1_1base_1_1Allocator.html#a93f1290160eae885a71f493380e2c90a',1,'embb::base::Allocator::deallocate()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#a71e51199e3b3d9398196962627155606',1,'embb::base::AllocatorCacheAligned::deallocate()']]],
  ['default_5fproblem_5fsize',['default_problem_size',['../structmtapi__ext__job__attributes__struct.html#a97de807d2820d156f375076a4291914f',1,'mtapi_ext_job_attributes_struct']]],
  ['defer_5flock',['defer_lock',['../group__CPP__BASE__MUTEX.html#gabb513e6cbe12335ac558b8be8e4c604e',1,'embb::base']]],
  ['deferlocktag',['DeferLockTag',['../structembb_1_1base_1_1DeferLockTag.html',1,'embb::base']]],
  ['delete',['Delete',['../classembb_1_1mtapi_1_1Action.html#a607f9fe4f60c768531b7ad7783e1e011',1,'embb::mtapi::Action::Delete()'],['../classembb_1_1mtapi_1_1Group.html#a986da76a1c6bbe07499386bb97dc197e',1,'embb::mtapi::Group::Delete()'],['../classembb_1_1mtapi_1_1Queue.html#a7ebda6e158d192f7d6a2229ab06ddc56',1,'embb::mtapi::Queue::Delete()'],['../classembb_1_1base_1_1Allocation.html#ae9f5e9b46e4424b400e167df026baa91',1,'embb::base::Allocation::Delete()']]],
  ['destroy',['destroy',['../classembb_1_1base_1_1Allocator.html#a333fa1965f6a6908aa8d9d628d88f167',1,'embb::base::Allocator']]],
  ['difference_5ftype',['difference_type',['../classembb_1_1base_1_1Allocator.html#af937e89cfb4667c9322c4840f86068d5',1,'embb::base::Allocator::difference_type()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#a30df9b124611c5334a64aba5198ff7d9',1,'embb::base::AllocatorCacheAligned::difference_type()']]],
  ['disable',['Disable',['../classembb_1_1mtapi_1_1Queue.html#a8d5ddf4a13d1aa8eef1dca67f453a6f7',1,'embb::mtapi::Queue::Disable(mtapi_timeout_t timeout)'],['../classembb_1_1mtapi_1_1Queue.html#acf179418c90e4ec854372f6c792826ee',1,'embb::mtapi::Queue::Disable()']]],
  ['domain_5fshared',['domain_shared',['../structmtapi__action__attributes__struct.html#ac7281279d6e03d70b6e90c7accc56467',1,'mtapi_action_attributes_struct::domain_shared()'],['../structmtapi__queue__attributes__struct.html#a30d7dbc8ed427dc9667eb958c231017c',1,'mtapi_queue_attributes_struct::domain_shared()']]],
  ['duration',['Duration',['../classembb_1_1base_1_1Duration.html',1,'embb::base']]],
  ['duration',['Duration',['../classembb_1_1base_1_1Duration.html#a7028f0ca7bd8bc27629cbd0f9997f4a0',1,'embb::base::Duration::Duration()'],['../classembb_1_1base_1_1Duration.html#aba9bfe9b0176e23db05d7711af8bb1c8',1,'embb::base::Duration::Duration(unsigned long long ticks)'],['../classembb_1_1base_1_1Duration.html#a24f0261ed074d97500b90e5c26420e54',1,'embb::base::Duration::Duration(const Duration&lt; Tick &gt; &amp;to_copy)']]],
  ['durationmicroseconds',['DurationMicroseconds',['../group__CPP__BASE__TIMEDURATION.html#gad55574d2bd1b72a88db71a028042bc6d',1,'embb::base']]],
  ['durationmilliseconds',['DurationMilliseconds',['../group__CPP__BASE__TIMEDURATION.html#ga8d3bc108aa5f77c538a1746e96ae1f0d',1,'embb::base']]],
  ['durationnanoseconds',['DurationNanoseconds',['../group__CPP__BASE__TIMEDURATION.html#ga400f31ab6b2a2394648016dbd1a17ce1',1,'embb::base']]],
  ['durationseconds',['DurationSeconds',['../group__CPP__BASE__TIMEDURATION.html#ga50fbe71248b5e271800cf245ec76c74e',1,'embb::base']]]
];
