var searchData=
[
  ['duration_20and_20time',['Duration and Time',['../group__C__BASE__DURATIONTIME.html',1,'']]],
  ['duration_20and_20time',['Duration and Time',['../group__CPP__BASE__TIMEDURATION.html',1,'']]],
  ['dataflow',['Dataflow',['../group__CPP__DATAFLOW.html',1,'']]]
];
