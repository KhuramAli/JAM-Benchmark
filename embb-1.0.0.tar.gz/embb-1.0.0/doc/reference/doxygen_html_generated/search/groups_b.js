var searchData=
[
  ['pools',['Pools',['../group__CPP__CONTAINERS__POOLS.html',1,'']]]
];
