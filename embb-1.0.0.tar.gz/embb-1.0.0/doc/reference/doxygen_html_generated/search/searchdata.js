var indexSectionsWithContent =
{
  0: "_abcdefghijlmnopqrstuvwyz~",
  1: "acdefgijlmnopqrstuwz",
  2: "abcdefghijlmnopqrstuwyz~",
  3: "_acdghilmnopqrstuw",
  4: "cdefimoprsv",
  5: "e",
  6: "e",
  7: "o",
  8: "abcdefgijlmpqrstvz",
  9: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "related",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends",
  8: "Modules",
  9: "Pages"
};

