var searchData=
[
  ['value_20pool_20concept',['Value Pool Concept',['../group__CPP__CONCEPTS__VALUE__POOL.html',1,'']]]
];
