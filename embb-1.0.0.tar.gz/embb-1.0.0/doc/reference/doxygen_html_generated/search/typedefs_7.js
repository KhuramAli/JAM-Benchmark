var searchData=
[
  ['pointer',['pointer',['../classembb_1_1base_1_1Allocator.html#a509bb033f52f7644d2fd69d2433229bf',1,'embb::base::Allocator::pointer()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#aebb7b99f8ec49b1f217effbecdee276f',1,'embb::base::AllocatorCacheAligned::pointer()']]]
];
