var searchData=
[
  ['function',['Function',['../classembb_1_1base_1_1Function.html',1,'embb::base']]],
  ['function_3c_20void_2c_20internal_3a_3alockfreempmcqueuenode_3c_20type_20_3e_20_2a_20_3e',['Function&lt; void, internal::LockFreeMPMCQueueNode&lt; Type &gt; * &gt;',['../classembb_1_1base_1_1Function.html',1,'embb::base']]],
  ['function_3c_20void_2c_20internal_3a_3alockfreestacknode_3c_20type_20_3e_20_2a_20_3e',['Function&lt; void, internal::LockFreeStackNode&lt; Type &gt; * &gt;',['../classembb_1_1base_1_1Function.html',1,'embb::base']]]
];
