var searchData=
[
  ['max_5factions',['max_actions',['../structmtapi__node__attributes__struct.html#ac6cdd1957816cc9505c093ac7d5abb5c',1,'mtapi_node_attributes_struct']]],
  ['max_5factions_5fper_5fjob',['max_actions_per_job',['../structmtapi__node__attributes__struct.html#a12abe742030f44fb82b0f1d0de9a814e',1,'mtapi_node_attributes_struct']]],
  ['max_5fgroups',['max_groups',['../structmtapi__node__attributes__struct.html#a58b8baed415ea4ce3dba32c252cfbff1',1,'mtapi_node_attributes_struct']]],
  ['max_5fjobs',['max_jobs',['../structmtapi__node__attributes__struct.html#a4d689f71b47011d31f910d5356b59168',1,'mtapi_node_attributes_struct']]],
  ['max_5fpriorities',['max_priorities',['../structmtapi__node__attributes__struct.html#a3bbc5c858c13d4eb4294a4cea50f1ea6',1,'mtapi_node_attributes_struct']]],
  ['max_5fqueues',['max_queues',['../structmtapi__node__attributes__struct.html#a1af1ff8fb47d0ba73dcd8498064051db',1,'mtapi_node_attributes_struct']]],
  ['max_5ftasks',['max_tasks',['../structmtapi__node__attributes__struct.html#afa3c60a4cca6296cd5e4e3d76c23e583',1,'mtapi_node_attributes_struct']]],
  ['mtapi_5fversion',['mtapi_version',['../structmtapi__info__struct.html#aaa5cc8c0f7d2597302e684438d8946f8',1,'mtapi_info_struct']]]
];
