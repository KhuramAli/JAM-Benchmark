var searchData=
[
  ['foreach',['Foreach',['../group__CPP__ALGORITHMS__FOREACH.html',1,'']]],
  ['function',['Function',['../group__CPP__BASE__FUNCTION.html',1,'']]]
];
