var searchData=
[
  ['priority',['priority',['../structmtapi__worker__priority__entry__struct.html#a58a4f41d401daaff39d2f60ce2c0dd51',1,'mtapi_worker_priority_entry_struct::priority()'],['../structmtapi__task__attributes__struct.html#a1b142c5bdf1027af4fa6364465b0ced0',1,'mtapi_task_attributes_struct::priority()'],['../structmtapi__queue__attributes__struct.html#ac1d60be6cbbb1057f89c27b64cbe5610',1,'mtapi_queue_attributes_struct::priority()']]],
  ['problem_5fsize',['problem_size',['../structmtapi__task__attributes__struct.html#a6ded00fea3f3ac54683d5b77a8a7018a',1,'mtapi_task_attributes_struct']]],
  ['problem_5fsize_5ffunc',['problem_size_func',['../structmtapi__ext__job__attributes__struct.html#ad2d497da0a8a3e30401789f6bf47db4a',1,'mtapi_ext_job_attributes_struct']]]
];
