var searchData=
[
  ['hardware_5fconcurrency',['hardware_concurrency',['../structmtapi__info__struct.html#a54bae741be04763eb029d1f263a1371c',1,'mtapi_info_struct']]]
];
