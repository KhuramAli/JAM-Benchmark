var searchData=
[
  ['adopt_5flock',['adopt_lock',['../group__CPP__BASE__MUTEX.html#ga53d9967b355d915f330ba64cce84d9f6',1,'embb::base']]],
  ['affinity',['affinity',['../structmtapi__action__attributes__struct.html#ac895917eded75e68ee6b78e00420cba9',1,'mtapi_action_attributes_struct::affinity()'],['../structmtapi__task__attributes__struct.html#af76918517d466ed46786485a33dc9276',1,'mtapi_task_attributes_struct::affinity()']]]
];
