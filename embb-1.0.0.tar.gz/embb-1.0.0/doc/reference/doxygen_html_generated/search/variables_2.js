var searchData=
[
  ['complete_5ffunc',['complete_func',['../structmtapi__task__attributes__struct.html#a8c49e4e23f4102e66f8b8a2973fe9ba4',1,'mtapi_task_attributes_struct']]],
  ['core_5faffinity',['core_affinity',['../structmtapi__node__attributes__struct.html#a2249a26715a42c9b54cef2fcd1857bdc',1,'mtapi_node_attributes_struct']]]
];
