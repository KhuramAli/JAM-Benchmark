var searchData=
[
  ['reference',['reference',['../classembb_1_1base_1_1Allocator.html#a297c0f965c8e92fdc3331c435391612e',1,'embb::base::Allocator::reference()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#a9a4c5783596212b976736c4289681cbf',1,'embb::base::AllocatorCacheAligned::reference()']]],
  ['result',['Result',['../structembb_1_1dataflow_1_1Network_1_1Inputs_1_1Types.html#a5d7211697c3fbe4d5cef328151863391',1,'embb::dataflow::Network::Inputs::Types::Result()'],['../structembb_1_1dataflow_1_1Network_1_1Outputs_1_1Types.html#adfecf3a54acb2e3a60fde3e2689845b3',1,'embb::dataflow::Network::Outputs::Types::Result()']]]
];
