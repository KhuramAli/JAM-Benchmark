var searchData=
[
  ['logging',['Logging',['../group__C__LOG.html',1,'']]],
  ['logging',['Logging',['../group__CPP__LOG.html',1,'']]]
];
