var searchData=
[
  ['zip_20iterator',['Zip Iterator',['../group__CPP__ALGORITHMS__ZIP__ITERATOR.html',1,'']]]
];
