var searchData=
[
  ['invoke',['Invoke',['../group__CPP__ALGORITHMS__INVOKE.html',1,'']]]
];
