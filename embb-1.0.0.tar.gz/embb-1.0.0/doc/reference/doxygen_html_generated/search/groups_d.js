var searchData=
[
  ['reduction',['Reduction',['../group__CPP__ALGORITHMS__REDUCTION.html',1,'']]]
];
