var searchData=
[
  ['used_5fmemory',['used_memory',['../structmtapi__info__struct.html#a673b985d3894717c36d7a24315982286',1,'mtapi_info_struct']]],
  ['user_5fdata',['user_data',['../structmtapi__task__attributes__struct.html#af7fdc091a2bdebc00371cf76bdc58719',1,'mtapi_task_attributes_struct']]]
];
