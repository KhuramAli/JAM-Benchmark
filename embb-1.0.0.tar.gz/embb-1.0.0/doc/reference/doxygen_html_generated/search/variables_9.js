var searchData=
[
  ['num_5fcores',['num_cores',['../structmtapi__node__attributes__struct.html#a0db7c7fbafc0e1f8890b5d109d90c598',1,'mtapi_node_attributes_struct']]],
  ['num_5finstances',['num_instances',['../structmtapi__task__attributes__struct.html#ad486a56f465b5890154dc38c5c785e91',1,'mtapi_task_attributes_struct']]],
  ['number_5fof_5fdomains',['number_of_domains',['../structmtapi__info__struct.html#ad422aae9d8efac7fb525887d8b9a2686',1,'mtapi_info_struct']]],
  ['number_5fof_5fnodes',['number_of_nodes',['../structmtapi__info__struct.html#afb58a89583cae096cf2b9020ae68dcdb',1,'mtapi_info_struct']]]
];
