var searchData=
[
  ['difference_5ftype',['difference_type',['../classembb_1_1base_1_1Allocator.html#af937e89cfb4667c9322c4840f86068d5',1,'embb::base::Allocator::difference_type()'],['../classembb_1_1base_1_1AllocatorCacheAligned.html#a30df9b124611c5334a64aba5198ff7d9',1,'embb::base::AllocatorCacheAligned::difference_type()']]],
  ['durationmicroseconds',['DurationMicroseconds',['../group__CPP__BASE__TIMEDURATION.html#gad55574d2bd1b72a88db71a028042bc6d',1,'embb::base']]],
  ['durationmilliseconds',['DurationMilliseconds',['../group__CPP__BASE__TIMEDURATION.html#ga8d3bc108aa5f77c538a1746e96ae1f0d',1,'embb::base']]],
  ['durationnanoseconds',['DurationNanoseconds',['../group__CPP__BASE__TIMEDURATION.html#ga400f31ab6b2a2394648016dbd1a17ce1',1,'embb::base']]],
  ['durationseconds',['DurationSeconds',['../group__CPP__BASE__TIMEDURATION.html#ga50fbe71248b5e271800cf245ec76c74e',1,'embb::base']]]
];
