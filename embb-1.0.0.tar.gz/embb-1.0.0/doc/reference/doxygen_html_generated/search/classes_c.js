var searchData=
[
  ['parallelprocess',['ParallelProcess',['../classembb_1_1dataflow_1_1Network_1_1ParallelProcess.html',1,'embb::dataflow::Network']]],
  ['placeholder',['Placeholder',['../classembb_1_1base_1_1Placeholder.html',1,'embb::base']]]
];
