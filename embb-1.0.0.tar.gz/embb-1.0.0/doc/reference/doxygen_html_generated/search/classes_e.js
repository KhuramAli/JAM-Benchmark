var searchData=
[
  ['rebind',['rebind',['../structembb_1_1base_1_1Allocator_1_1rebind.html',1,'embb::base::Allocator']]],
  ['rebind',['rebind',['../structembb_1_1base_1_1AllocatorCacheAligned_1_1rebind.html',1,'embb::base::AllocatorCacheAligned']]],
  ['recursivemutex',['RecursiveMutex',['../classembb_1_1base_1_1RecursiveMutex.html',1,'embb::base']]],
  ['resourcebusyexception',['ResourceBusyException',['../classembb_1_1base_1_1ResourceBusyException.html',1,'embb::base']]]
];
