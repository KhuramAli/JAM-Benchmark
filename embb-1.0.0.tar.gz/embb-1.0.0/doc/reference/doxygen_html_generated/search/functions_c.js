var searchData=
[
  ['network',['Network',['../classembb_1_1dataflow_1_1Network.html#a34161a7f75d5f4cb66ff0274fbeba54b',1,'embb::dataflow::Network::Network()'],['../classembb_1_1dataflow_1_1Network.html#a2dbec122598b252f3aa1ed027d44a935',1,'embb::dataflow::Network::Network(int slices)'],['../classembb_1_1dataflow_1_1Network.html#a73e687e4a06caeaae93831b0d549f7f1',1,'embb::dataflow::Network::Network(embb::mtapi::ExecutionPolicy const &amp;policy)'],['../classembb_1_1dataflow_1_1Network.html#ac93a672aaf5fe0e7a2e267ea50584227',1,'embb::dataflow::Network::Network(int slices, embb::mtapi::ExecutionPolicy const &amp;policy)']]],
  ['new',['New',['../classembb_1_1base_1_1Allocation.html#a3abe57221bfb97d9ea7563ac1b79fb4f',1,'embb::base::Allocation::New()'],['../classembb_1_1base_1_1Allocation.html#a2c2e9a011338c2e923e1df97c29382cb',1,'embb::base::Allocation::New(Arg1 argument1,...)']]],
  ['nodeattributes',['NodeAttributes',['../classembb_1_1mtapi_1_1NodeAttributes.html#aa156b6d3ea3be7a16b1ad4e8af073be5',1,'embb::mtapi::NodeAttributes::NodeAttributes()'],['../classembb_1_1mtapi_1_1NodeAttributes.html#a860e5de47bd95269a2b7e5096993bda2',1,'embb::mtapi::NodeAttributes::NodeAttributes(NodeAttributes const &amp;other)']]],
  ['nomemoryexception',['NoMemoryException',['../classembb_1_1base_1_1NoMemoryException.html#aed94dab43274494b18ede24f6c943363',1,'embb::base::NoMemoryException']]],
  ['notifyall',['NotifyAll',['../classembb_1_1base_1_1ConditionVariable.html#a625f009e68dd686cc326d49cc6804f81',1,'embb::base::ConditionVariable']]],
  ['notifyone',['NotifyOne',['../classembb_1_1base_1_1ConditionVariable.html#a0039d7e05123446f5caa77db67d9f5a8',1,'embb::base::ConditionVariable']]]
];
