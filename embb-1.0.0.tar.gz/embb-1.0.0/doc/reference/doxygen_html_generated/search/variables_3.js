var searchData=
[
  ['default_5fproblem_5fsize',['default_problem_size',['../structmtapi__ext__job__attributes__struct.html#a97de807d2820d156f375076a4291914f',1,'mtapi_ext_job_attributes_struct']]],
  ['defer_5flock',['defer_lock',['../group__CPP__BASE__MUTEX.html#gabb513e6cbe12335ac558b8be8e4c604e',1,'embb::base']]],
  ['domain_5fshared',['domain_shared',['../structmtapi__action__attributes__struct.html#ac7281279d6e03d70b6e90c7accc56467',1,'mtapi_action_attributes_struct::domain_shared()'],['../structmtapi__queue__attributes__struct.html#a30d7dbc8ed427dc9667eb958c231017c',1,'mtapi_queue_attributes_struct::domain_shared()']]]
];
