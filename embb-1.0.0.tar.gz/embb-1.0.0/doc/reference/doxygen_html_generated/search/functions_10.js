var searchData=
[
  ['recursivemutex',['RecursiveMutex',['../classembb_1_1base_1_1RecursiveMutex.html#a3d06e683aba552fb212eb44eac532631',1,'embb::base::RecursiveMutex']]],
  ['reduce',['Reduce',['../group__CPP__ALGORITHMS__REDUCTION.html#gafad9c422a2ca79ca0121e0fd0302c023',1,'embb::algorithms']]],
  ['release',['Release',['../classembb_1_1base_1_1UniqueLock.html#a2e5449d90c2477866b24a497b88e28e8',1,'embb::base::UniqueLock']]],
  ['remove',['Remove',['../classembb_1_1base_1_1CoreSet.html#aabb66de3f4ab87c5a880eecb0e9799ce',1,'embb::base::CoreSet']]],
  ['removeworker',['RemoveWorker',['../classembb_1_1mtapi_1_1ExecutionPolicy.html#ad49cf0145a88483a041f6bbd5607c57d',1,'embb::mtapi::ExecutionPolicy']]],
  ['reset',['Reset',['../classembb_1_1base_1_1CoreSet.html#a0b786f2677e8a80e2d152d6bc80d149b',1,'embb::base::CoreSet']]],
  ['resourcebusyexception',['ResourceBusyException',['../classembb_1_1base_1_1ResourceBusyException.html#a47d35f54ba21c5badafdb265bda46eea',1,'embb::base::ResourceBusyException']]]
];
