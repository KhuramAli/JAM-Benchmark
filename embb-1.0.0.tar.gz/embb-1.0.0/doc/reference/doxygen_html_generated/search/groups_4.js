var searchData=
[
  ['error',['Error',['../group__C__BASE__ERROR.html',1,'']]],
  ['exception',['Exception',['../group__CPP__BASE__EXCEPTIONS.html',1,'']]]
];
