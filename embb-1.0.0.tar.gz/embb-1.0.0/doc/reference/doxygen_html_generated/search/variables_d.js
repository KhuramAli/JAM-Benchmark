var searchData=
[
  ['retain',['retain',['../structmtapi__queue__attributes__struct.html#a292bfdfe8496340fa6de3ba4e96a9768',1,'mtapi_queue_attributes_struct']]],
  ['reuse_5fmain_5fthread',['reuse_main_thread',['../structmtapi__node__attributes__struct.html#afb1b308446c9872276a6582c3d547cbc',1,'mtapi_node_attributes_struct']]]
];
