var searchData=
[
  ['global',['global',['../structmtapi__action__attributes__struct.html#a6186ae127d528484b4e55069ac56e222',1,'mtapi_action_attributes_struct::global()'],['../structmtapi__queue__attributes__struct.html#a27a9f3f57b6b3efd492e8cf86caf748f',1,'mtapi_queue_attributes_struct::global()']]]
];
